from django.apps import AppConfig


class AppUplaodConfig(AppConfig):
    name = 'app_uplaod'
